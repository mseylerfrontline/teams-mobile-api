(function() {
  var apn, apnConnection, device, gcm;

  apn = require('apn');

  gcm = require('gcm');

  apnConnection = new apn.Connection({});

  device = new apn.Device('token');

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInB1c2guY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQTs7RUFBQSxHQUFBLEdBQU0sT0FBQSxDQUFRLEtBQVI7O0VBQ04sR0FBQSxHQUFNLE9BQUEsQ0FBUSxLQUFSOztFQUVOLGFBQUEsR0FBb0IsSUFBQSxHQUFHLENBQUMsVUFBSixDQUFlLEVBQWY7O0VBSXBCLE1BQUEsR0FBYSxJQUFBLEdBQUcsQ0FBQyxNQUFKLENBQVcsT0FBWDtBQVBiIiwiZmlsZSI6InB1c2guanMiLCJzb3VyY2VSb290IjoiL3NvdXJjZS8iLCJzb3VyY2VzQ29udGVudCI6WyJhcG4gPSByZXF1aXJlICdhcG4nXG5nY20gPSByZXF1aXJlICdnY20nXG5cbmFwbkNvbm5lY3Rpb24gPSBuZXcgYXBuLkNvbm5lY3Rpb24ge1xuXG59XG5cbmRldmljZSA9IG5ldyBhcG4uRGV2aWNlICd0b2tlbidcbiJdfQ==