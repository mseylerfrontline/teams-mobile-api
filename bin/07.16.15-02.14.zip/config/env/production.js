(function() {
  var production;

  production = {
    mongoURL: 'mongodb://localhost:27017/local',
    port: 7500,
    ip: '172.18.0.30'
  };

  module.exports = production;

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbmZpZy9lbnYvcHJvZHVjdGlvbi5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7QUFBQSxNQUFBOztFQUFBLFVBQUEsR0FDRztJQUFBLFFBQUEsRUFBVSxpQ0FBVjtJQUNBLElBQUEsRUFBTSxJQUROO0lBRUEsRUFBQSxFQUFJLGFBRko7OztFQUlILE1BQU0sQ0FBQyxPQUFQLEdBQWlCO0FBTGpCIiwiZmlsZSI6ImNvbmZpZy9lbnYvcHJvZHVjdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIvc291cmNlLyIsInNvdXJjZXNDb250ZW50IjpbIiMgUHJvZHVjdGlvbiBlbnZpcm9ubWVudC1zcGVjaWZpYyBjb25maWd1cmF0aW9uXG5cbnByb2R1Y3Rpb24gPVxuICAgbW9uZ29VUkw6ICdtb25nb2RiOi8vbG9jYWxob3N0OjI3MDE3L2xvY2FsJ1xuICAgcG9ydDogNzUwMFxuICAgaXA6ICcxNzIuMTguMC4zMCdcblxubW9kdWxlLmV4cG9ydHMgPSBwcm9kdWN0aW9uXG4iXX0=